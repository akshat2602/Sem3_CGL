#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QColorDialog>
#include <QDebug>
#include<QMouseEvent>
#include<QMessageBox>
#include <cmath>
using namespace std;

QImage img(700,700,QImage::Format_RGB888);
QColor c=qRgb(11, 0, 165),backColor=qRgb(161, 218, 255);
int vertices=0,temp,i,j,x_vertex[10],y_vertex[10],xTranslate,yTranslate;
float rotateValue=0,PI=3.142,rot,xScale,yScale;
bool start=true,buttonActive=false;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    backgroundFill();
    ui->scaleButton->setEnabled(buttonActive);
    ui->translateButton->setEnabled(buttonActive);
    ui->rotateButton->setEnabled(buttonActive);
}

MainWindow::~MainWindow()
{
    delete ui;
}

class Matrix{
public:
    double me[10][3];
public:
    void formvertexMatrix(){
        //form vertex matrix
        for(i=0;i<vertices;i++){
            me[i][0]=x_vertex[i];
            me[i][1]=y_vertex[i];
            me[i][2]=1;
        }
    }
    void formtranslateMatrix(int xTranslate,int yTranslate){
        me[0][0]=1;
        me[0][1]=0;
        me[0][2]=0;
        me[1][0]=0;
        me[1][1]=1;
        me[1][2]=0;
        me[2][0]=xTranslate;
        me[2][1]=yTranslate;
        me[2][2]=1;
    }
    void formScaleMatrix(float xScale,float yScale){
        me[0][0]=xScale;
        me[0][1]=0;
        me[0][2]=0;
        me[1][0]=0;
        me[1][1]=yScale;
        me[1][2]=0;
        me[2][0]=0;
        me[2][1]=0;
        me[2][2]=1;
    }
    void formRotateMatrix(float rotateValue){
        rot=rotateValue*PI/180.0;
        me[0][0]=cos(rot);
        me[0][1]=-sin(rot);
        me[0][2]=0;
        me[1][0]=sin(rot);
        me[1][1]=cos(rot);
        me[1][2]=0;
        me[2][0]=0;
        me[2][1]=0;
        me[2][2]=1;
    }
    Matrix operator*(Matrix transformMatrix){
        Matrix transformedMatrix;
        transformedMatrix.formvertexMatrix();
        for(i=0;i<vertices;i++){
            for(j=0;j<3;j++){
                transformedMatrix.me[i][j]=0;
                for(int k=0;k<3;k++){
                    transformedMatrix.me[i][j]+=me[i][k]*transformMatrix.me[k][j];
                }
            }
        }
        for(i=0;i<vertices;i++){
            for(j=0;j<3;j++){
                me[i][j]=int(transformedMatrix.me[i][j]);
            }
        }
        return transformedMatrix;
    }
};

Matrix vertexMatrix,rotationMatrix,translationMatrix,scalingMatrix,transformedMatrix;

//fills background color of iutput screen
void MainWindow::backgroundFill(){
    for(i=0;i<700;i++){
        dda_line(0,i,699,i,backColor);
    }
}

//check whether there is no input provided
bool MainWindow::null_error(QString a)
{
    if(a==NULL)
    {
        return false;
    }
    else{
        return true;
    }
}

//checks if input is an integer
bool MainWindow::is_int(QString a){
    char validList[]={'1','2','3','4','5','6','7','8','9','0','-'};
    int right=0;
    for (unsigned long long j=0;j<sizeof(validList);j++){
        for (int i=0;i<a.size();i++){
            if(a[i]==validList[j]){
                right+=1;
            }
        }
    }
    if(right!=a.size()){return false;}
    else{return true;}
}

//checks if input is a floating number
bool MainWindow::is_float(QString a){
    char validList[]={'1','2','3','4','5','6','7','8','9','0','-','.'};
    int right=0;
    for (unsigned long long j=0;j<sizeof(validList);j++){
        for (int i=0;i<a.size();i++){
            if(a[i]==validList[j]){
                right+=1;
            }
        }
    }
    if(right!=a.size()){return false;}
    else{return true;}
}

//check if point lies within the output label
bool MainWindow::limit_error(int a,int b){
    if(a>=0 && a<=700 && b>=0 && b<=700){
        return true;
    }
    else{
        return false;
    }
};

//dda line drawing algorithm
void MainWindow::dda_line(int x1,int y1,int x2,int y2,QColor c)
{
    float dx,dy,length,x,y;
    dx=x2-x1;
    dy=y2-y1;
    x=x1;
    y=y1;
    if(abs(dx)>abs(dy)){
        length=abs(dx);
    }
    else{
        length=abs(dy);
    }
    dx=dx/length;
    dy=dy/length;
    int i=0;
    while(i<=length){
        img.setPixel(x,y,c.rgb());
        x+=dx;
        y+=dy;
        i++;
    }
    ui->outputScreen->setPixmap((QPixmap::fromImage(img)));
}

//mouse press on output label is takes as the vertex of the polygon
void MainWindow::mousePressEvent(QMouseEvent *ev)
{
    if (start){
        int p = ev->pos().x();
        int q = ev->pos().y();
        if(limit_error(p,q)){
            x_vertex[vertices] = p;
            y_vertex[vertices] = q;
            if (ev->button() == Qt::RightButton){
                dda_line(x_vertex[0], y_vertex[0], x_vertex[vertices - 1], y_vertex[vertices - 1],c);
                start = false;
                vertexMatrix.formvertexMatrix();
                buttonActive=true;
                ui->scaleButton->setEnabled(buttonActive);
                ui->translateButton->setEnabled(buttonActive);
                ui->rotateButton->setEnabled(buttonActive);
            }
            else{
                if (vertices > 0){
                    dda_line(x_vertex[vertices - 1], y_vertex[vertices - 1], x_vertex[vertices], y_vertex[vertices],c);
                }
            }
            vertices++;
        }
        else{
            QMessageBox exception;
            exception.critical(0,"Not within the limit","Enter Integer Value inside the screen");
            exception.setFixedSize(600,300);
            exception.exec();
        }

    }
}

//function to draw the transformed polygon
void MainWindow::drawTransformedPolygon(){
    backgroundFill();

    for(i=0;i<vertices;i++){
        x_vertex[i]=transformedMatrix.me[i][0];
        y_vertex[i]=transformedMatrix.me[i][1];
    }
    for(i=0;i<vertices-2;i++){
        dda_line(x_vertex[i],y_vertex[i],x_vertex[i+1],y_vertex[i+1],c);
    }
    dda_line(x_vertex[vertices-2],y_vertex[vertices-2],x_vertex[0],y_vertex[0],c);
}

//clears the output label
void MainWindow::on_clear_button_clicked()
{
    for(i=0;i<vertices;i++){
        x_vertex[i]=0;
        y_vertex[i]=0;
    }
    vertices=0;
    QImage* newImage=new QImage(700,700,QImage::Format_RGB888);
    img=*newImage;
    backgroundFill();
    ui->outputScreen->setPixmap((QPixmap::fromImage(img)));
    start=true;
    buttonActive=false;
    ui->scaleButton->setEnabled(buttonActive);
    ui->translateButton->setEnabled(buttonActive);
    ui->rotateButton->setEnabled(buttonActive);

}

void MainWindow::on_clear_button_2_clicked()
{
    c = QColorDialog::getColor(Qt::white);
}

void MainWindow::on_scaleButton_clicked()
{
    bool proceedX,proceedY;
    QString x=ui->xScale->toPlainText();
    QString y=ui->yScale->toPlainText();
    proceedX=null_error(x);
    proceedY=null_error(y);
    if (proceedX and proceedY)
    {
        if(is_float(x) and is_float(y)){
            xScale=x.toFloat();
            yScale=y.toFloat();
            //scale matrix formation
            scalingMatrix.formScaleMatrix(xScale,yScale);
            transformedMatrix=vertexMatrix*scalingMatrix;
            //call function to draw the new transformed polygon
            drawTransformedPolygon();
            ui->xScale->clear();
            ui->yScale->clear();
        }
        else{
            QMessageBox exception;
            exception.critical(0,"Not a number","Enter Integer Value");
            exception.setFixedSize(600,300);
            exception.exec();
        }
    }
    else{
        QMessageBox exception;
        exception.critical(0,"NULL Value","Enter Integer Value");
        exception.setFixedSize(600,300);
        exception.exec();
    }
}

void MainWindow::on_translateButton_clicked()
{
    bool proceedX,proceedY;
    QString x=ui->xTranslate->toPlainText();
    QString y=ui->yTranslate->toPlainText();
    proceedX=null_error(x);
    proceedY=null_error(y);
    if (proceedX and proceedY)
    {
        if(is_int(x) and is_int(y)){
            xTranslate=x.toInt();
            yTranslate=y.toInt();
            //translate matrix formation
            translationMatrix.formtranslateMatrix(xTranslate,yTranslate);
            transformedMatrix=vertexMatrix*translationMatrix;
            //call function to draw the new transformed polygon
            drawTransformedPolygon();
            ui->xTranslate->clear();
            ui->yTranslate->clear();
        }
        else{
            QMessageBox exception;
            exception.critical(0,"Not a number","Enter Integer Value");
            exception.setFixedSize(600,300);
            exception.exec();
        }
    }
    else{
        QMessageBox exception;
        exception.critical(0,"NULL Value","Enter Integer Value");
        exception.setFixedSize(600,300);
        exception.exec();
    }
}

void MainWindow::on_rotateButton_clicked()
{
    bool proceedX;
    QString x=ui->angle->toPlainText();
    proceedX=null_error(x);
    if (proceedX)
    {
        if(is_int(x)){
            rotateValue=x.toFloat();
            //rotate matrix formation
            rotationMatrix.formRotateMatrix(rotateValue);
            transformedMatrix=vertexMatrix*rotationMatrix;
            //call function to draw the new transformed polygon
            drawTransformedPolygon();
            ui->angle->clear();
        }
        else{
            QMessageBox exception;
            exception.critical(0,"Not a number","Enter Integer Value");
            exception.setFixedSize(600,300);
            exception.exec();
        }
    }
    else{
        QMessageBox exception;
        exception.critical(0,"NULL Value","Enter Integer Value");
        exception.setFixedSize(600,300);
        exception.exec();
    }
}

