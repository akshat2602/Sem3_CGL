#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();


private slots:
    void dda_line(int,int,int,int,QColor);
    void mousePressEvent(QMouseEvent *ev);
    void on_clear_button_clicked();
    bool limit_error(int,int);
    void on_clear_button_2_clicked();
    void backgroundFill();
    void on_scaleButton_clicked();
    bool null_error(QString);
    bool is_int(QString);
    bool is_float(QString);
    void drawTransformedPolygon();

    void on_translateButton_clicked();

    void on_rotateButton_clicked();


private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
